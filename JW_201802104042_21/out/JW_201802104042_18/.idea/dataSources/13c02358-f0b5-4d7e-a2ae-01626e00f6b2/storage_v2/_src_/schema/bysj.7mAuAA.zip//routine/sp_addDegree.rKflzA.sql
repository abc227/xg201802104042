create
    definer = root@localhost procedure sp_addDegree(IN no varchar(255), IN description varchar(255),
                                                    IN remarks varchar(255), OUT id int)
begin 
insert into Degree(no,description,remarks)
values(no,description,remarks);
select last_insert_id() into id;
end;

