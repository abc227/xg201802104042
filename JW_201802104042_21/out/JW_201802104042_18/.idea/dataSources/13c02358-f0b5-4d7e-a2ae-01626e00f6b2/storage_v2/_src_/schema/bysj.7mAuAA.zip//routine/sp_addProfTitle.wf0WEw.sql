create
    definer = root@localhost procedure sp_addProfTitle(IN description varchar(255), IN no varchar(255),
                                                       IN remarks varchar(255), OUT id int)
begin 
insert into ProfTitle(no,description,remarks)
values(no,description,remarks);
select last_insert_id() into id;
end;

